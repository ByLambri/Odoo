# -*- coding: utf-8 -*-
# from odoo import http


# class OnlinepcApp(http.Controller):
#     @http.route('/onlinepc_app/onlinepc_app', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/onlinepc_app/onlinepc_app/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('onlinepc_app.listing', {
#             'root': '/onlinepc_app/onlinepc_app',
#             'objects': http.request.env['onlinepc_app.onlinepc_app'].search([]),
#         })

#     @http.route('/onlinepc_app/onlinepc_app/objects/<model("onlinepc_app.onlinepc_app"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('onlinepc_app.object', {
#             'object': obj
#         })
