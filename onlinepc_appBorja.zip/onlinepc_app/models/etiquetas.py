# -*- coding: utf-8 -*-

from odoo import models, fields, api

class tipos_etiquetas(models.Model):
    _name = 'onlinepc.etiquetas'
    _description = 'Tipos de etiquetas para propiedades'

    name = fields.Char(string='Etiqueta',required='True')
    
    _sql_constraints = [('unique_tag', 'unique(name)','La etiqueta debe ser única')]
