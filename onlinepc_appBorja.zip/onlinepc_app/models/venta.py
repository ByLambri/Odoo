# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Venta(models.Model):
    _name = 'onlinepc.venta'

    modelo = fields.Many2one('onlinepc.modelo', string='Líneas de Venta')
    estado = fields.Selection(string='', selection=[('vendida', 'Vendida'), ('pendiente', 'Pendiente'),
            ('pendiente_de_envio', 'Pendiente de envio')])
    vendedor = fields.Many2one('res.users', string='Vendedor', default=lambda self: self.env.user, copy=False,required=True)
    comprador = fields.Many2one('res.partner', string='Comprador',required=True)
    envio = fields.Boolean(string='envio', default=False)
    transportista = fields.Selection(string='', selection=[('gls', 'GLS'), ('seur', 'Seur'),
            ('ups', 'ups'),('nacex', 'Nacex'),('correos', 'Correos')])
    direccion = fields.Text(string='Dirección de Envio')

