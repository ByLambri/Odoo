#-*- coding: utf-8 -*-


from odoo import models, fields, api


class onlinepc_app(models.Model):
    _name = 'onlinepc.modelo'
    _description = 'desc'

    name = fields.Char(string='Nombre del Producto',required=True)
    categorias = fields.Selection(string='',selection = [('mecanismos_electronicos','Mecanismos electronicos'), ('herramientas_electricas','Herramientas eléctricas'),
        ('iluminacion','Iluminación'),('cables_y_conductores_electricos','Cables y conductores eléctricos'),('climatizacion','Climatización'),('placas_solares','Placas Solares'),('placas_solares','Placas Solares')])
    precio = fields.Float(string='Precio')
    cantidad = fields.Integer(string='Cantidad',default = '1',readonly=True)
    peso = fields.Float(string='Peso')
    fecha = fields.Date(string='Fecha de venta')
    descripcion = fields.Text(string='Descripción')
    etiqueta = fields.Many2many('onlinepc.etiquetas', string="Etiquetas")
    vendedor = fields.Many2one('res.users', string='Vendedor', default=lambda self: self.env.user)
    proveedor = fields.Many2one('res.partner', string='Comprador')
    observaciones = fields.Text(string='Observaciones')
    metros = fields.Float(string='Metros',invisible=True)
    lineas_de_venta = fields.One2many('onlinepc.venta', 'modelo', string='Líneas de Venta')
    calidad =  fields.Selection(string='Calidad', selection=[('alta', 'Alta'), ('media', 'Media'), ('baja', 'Baja')])
    garantia = fields.Selection(string='Garantia',selection=[('1_mes', '1 Mes'), ('3_meses', '3 Meses'), ('6_meses', '6 Meses'),('1_año', '1 Año')])
    precioTotal = fields.Float(string='Precio total',compute = 'precios_total',readonly=True)

    def sumaCantidad(self):
        self.cantidad = self.cantidad + 1
        return True

    def restaCantidad(self):
        self.cantidad = self.cantidad - 1
        return True

    @api.depends('precio','cantidad')
    def precios_total(self):
        for total in self:
            total.precioTotal = total.precio * total.cantidad


    @api.onchange('categorias','calidad')
    def onchange_categorias(self):
        precio_unitario = 0
        if self.categorias == 'mecanismos_electronicos':
            precio_unitario = 215
            self.precio = precio_unitario
        elif self.categorias == 'herramientas_electricas':
            precio_unitario = 85
            self.precio = precio_unitario
        elif self.categorias == 'iluminacion':
            precio_unitario = 365
            self.precio = precio_unitario
        elif self.categorias == 'cables_y_conductores_electricos':
            precio_unitario = 60
            self.precio = precio_unitario
        elif self.categorias == 'climatizacion':
            precio_unitario = 497
            self.precio = precio_unitario
        elif self.categorias == 'videovigilancia':
            precio_unitario = 314
            self.precio = precio_unitario
        elif self.categorias == 'placas_solares':
            precio_unitario = 5862
            self.precio = precio_unitario

            _sql_constraints = [
                ('check_cantidad', 'CHECK(cantidad >= 0)', 'La cantidad no puede ser negativa.'),
                ('check_peso', 'CHECK(peso >= 0)', 'El peso del producto debe ser positivo.'),
                ('check_peso', 'CHECK(peso >= 0)', 'El peso del producto debe ser positivo.'),
                ('check_precio', 'CHECK(precio >= 0)', 'El precio del producto debe ser positivo.'),
                ('check_peso', 'CHECK(peso >= 0)', 'El peso del producto debe ser positivo.')]










